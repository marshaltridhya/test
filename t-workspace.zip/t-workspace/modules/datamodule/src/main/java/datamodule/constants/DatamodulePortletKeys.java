package datamodule.constants;

/**
 * @author Marshal Dekivadiya
 */
public class DatamodulePortletKeys {

	public static final String DATAMODULE =
		"datamodule_DatamodulePortlet";

}