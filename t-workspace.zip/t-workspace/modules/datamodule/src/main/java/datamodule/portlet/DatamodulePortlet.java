package datamodule.portlet;

import datamodule.constants.DatamodulePortletKeys;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.document.library.kernel.service.DLFileEntryLocalServiceUtil;
import com.liferay.journal.model.JournalArticle;
import com.liferay.journal.service.JournalArticleLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.repository.model.FileEntry;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.util.LocaleUtil;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.IOException;
import java.util.Locale;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.swing.JOptionPane;

import org.osgi.service.component.annotations.Component;

/**
 * @author Marshal Dekivadiya
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Datamodule",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + DatamodulePortletKeys.DATAMODULE,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class DatamodulePortlet extends MVCPortlet {
	
	@Override
	public void doView(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
		
			try {
				JournalArticle list = JournalArticleLocalServiceUtil.getArticle(45627);
				System.out.println("getArticleId: "+JournalArticleLocalServiceUtil.getArticle(45627).getContent());			
			} catch (PortalException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				System.out.println("File entery: "+DLFileEntryLocalServiceUtil.getDLFileEntry(36793).getTitle());
				
			} catch (PortalException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				//User user =  UserLocalServiceUtil.createUser(35334);
				
			/*
			 * user.setFirstName("manthan"); user.setLastName("patel");
			 * user.setEmailAddress("testt@gmail.com"); user.setJobTitle("Developer");
			 * user.setPassword("testt"); user.setMvccVersion(66);
			 * user.setCtCollectionId(0); user.setCompanyId(20097);
			 * user.setDefaultUser(false); user.setContactId(20130);
			 * user.setPasswordEncrypted(false); user.setScreenName("marshal");
			 */
				
//				User user = UserLocalServiceUtil.createUser(7652);
//				user.setFirstName("avan");
//				user.setMiddleName("ABC");
//				user.setLastName("patel");
//				user.setEmailAddress("t@gmail.com");
//				user.setScreenName("avan");
//				user.setPassword("avan");
//				user.setAgreedToTermsOfUse(true);
//
//				System.out.println("User Model: "+user);
//				
//			UserLocalServiceUtil.addUser(user);
				//User user = null;
			
			
				
			  UserLocalServiceUtil.addUser(0, PortalUtil.getDefaultCompanyId(), false,
			  "test", "test", true, "", "ashish1@gmail.com", LocaleUtil.getDefault(),
			  "Ashish", "Rajesh", "Inani", 0l, 0l, true, 01, 01, 1970, "", new long[]
			  {20121}, new long[0], new long[0], new long[0], false, null);
			  
				//user.setPasswordReset(false);
				//UserLocalServiceUtil.updateUser(user);

//				UserLocalServiceUtil.addUser(user);
				//UserLocalServiceUtil.addUser(7856, 20097, true, "testt", "testt", true, "marshal", "testt@gmail.com", "local", "jigs", "p", "kothari",null, null, true, null, null,null, "Devloper", null, null, null, null, null, null);
				}
		
	 catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			
			try {
				RoleLocalServiceUtil.addUserRole(45727, 20104);
				//RoleLocalServiceUtil.getRole(20106);
				//RoleLocalServiceUtil.addUserRole(232, 121);
				//RoleLocalServiceUtil.setUserRoles(20102, 20106);
				System.out.println(RoleLocalServiceUtil.getRole(20107).getName());
				
			} catch (PortalException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		super.doView(renderRequest, renderResponse);
	}
}