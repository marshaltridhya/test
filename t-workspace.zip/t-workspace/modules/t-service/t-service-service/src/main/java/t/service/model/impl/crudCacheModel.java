/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package t.service.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

import t.service.model.crud;

/**
 * The cache model class for representing crud in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class crudCacheModel implements CacheModel<crud>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof crudCacheModel)) {
			return false;
		}

		crudCacheModel crudCacheModel = (crudCacheModel)object;

		if (id == crudCacheModel.id) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, id);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(29);

		sb.append("{id=");
		sb.append(id);
		sb.append(", firstName=");
		sb.append(firstName);
		sb.append(", lastName=");
		sb.append(lastName);
		sb.append(", email=");
		sb.append(email);
		sb.append(", password=");
		sb.append(password);
		sb.append(", mobileNo=");
		sb.append(mobileNo);
		sb.append(", dateOfBirth=");
		sb.append(dateOfBirth);
		sb.append(", gender=");
		sb.append(gender);
		sb.append(", hobby=");
		sb.append(hobby);
		sb.append(", address=");
		sb.append(address);
		sb.append(", stream=");
		sb.append(stream);
		sb.append(", city=");
		sb.append(city);
		sb.append(", language=");
		sb.append(language);
		sb.append(", image=");
		sb.append(image);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public crud toEntityModel() {
		crudImpl crudImpl = new crudImpl();

		crudImpl.setId(id);

		if (firstName == null) {
			crudImpl.setFirstName("");
		}
		else {
			crudImpl.setFirstName(firstName);
		}

		if (lastName == null) {
			crudImpl.setLastName("");
		}
		else {
			crudImpl.setLastName(lastName);
		}

		if (email == null) {
			crudImpl.setEmail("");
		}
		else {
			crudImpl.setEmail(email);
		}

		if (password == null) {
			crudImpl.setPassword("");
		}
		else {
			crudImpl.setPassword(password);
		}

		crudImpl.setMobileNo(mobileNo);

		if (dateOfBirth == Long.MIN_VALUE) {
			crudImpl.setDateOfBirth(null);
		}
		else {
			crudImpl.setDateOfBirth(new Date(dateOfBirth));
		}

		if (gender == null) {
			crudImpl.setGender("");
		}
		else {
			crudImpl.setGender(gender);
		}

		if (hobby == null) {
			crudImpl.setHobby("");
		}
		else {
			crudImpl.setHobby(hobby);
		}

		if (address == null) {
			crudImpl.setAddress("");
		}
		else {
			crudImpl.setAddress(address);
		}

		if (stream == null) {
			crudImpl.setStream("");
		}
		else {
			crudImpl.setStream(stream);
		}

		if (city == null) {
			crudImpl.setCity("");
		}
		else {
			crudImpl.setCity(city);
		}

		if (language == null) {
			crudImpl.setLanguage("");
		}
		else {
			crudImpl.setLanguage(language);
		}

		if (image == null) {
			crudImpl.setImage("");
		}
		else {
			crudImpl.setImage(image);
		}

		crudImpl.resetOriginalValues();

		return crudImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		id = objectInput.readInt();
		firstName = objectInput.readUTF();
		lastName = objectInput.readUTF();
		email = objectInput.readUTF();
		password = objectInput.readUTF();

		mobileNo = objectInput.readLong();
		dateOfBirth = objectInput.readLong();
		gender = objectInput.readUTF();
		hobby = objectInput.readUTF();
		address = objectInput.readUTF();
		stream = objectInput.readUTF();
		city = objectInput.readUTF();
		language = objectInput.readUTF();
		image = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeInt(id);

		if (firstName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(firstName);
		}

		if (lastName == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(lastName);
		}

		if (email == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (password == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(password);
		}

		objectOutput.writeLong(mobileNo);
		objectOutput.writeLong(dateOfBirth);

		if (gender == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(gender);
		}

		if (hobby == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(hobby);
		}

		if (address == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(address);
		}

		if (stream == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(stream);
		}

		if (city == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(city);
		}

		if (language == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(language);
		}

		if (image == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(image);
		}
	}

	public int id;
	public String firstName;
	public String lastName;
	public String email;
	public String password;
	public long mobileNo;
	public long dateOfBirth;
	public String gender;
	public String hobby;
	public String address;
	public String stream;
	public String city;
	public String language;
	public String image;

}