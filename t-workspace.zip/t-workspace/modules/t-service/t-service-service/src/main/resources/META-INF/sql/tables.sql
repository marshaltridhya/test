create table FOO_crud (
	id_ INTEGER not null primary key,
	firstName VARCHAR(75) null,
	lastName VARCHAR(75) null,
	email VARCHAR(75) null,
	password_ VARCHAR(75) null,
	mobileNo LONG,
	dateOfBirth DATE null,
	gender VARCHAR(75) null,
	hobby VARCHAR(75) null,
	address VARCHAR(75) null,
	stream VARCHAR(75) null,
	city VARCHAR(75) null,
	language VARCHAR(75) null,
	image VARCHAR(75) null
);