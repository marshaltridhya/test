/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package t.service.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link t.service.service.http.crudServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @deprecated As of Athanasius (7.3.x), with no direct replacement
 * @generated
 */
@Deprecated
public class crudSoap implements Serializable {

	public static crudSoap toSoapModel(crud model) {
		crudSoap soapModel = new crudSoap();

		soapModel.setId(model.getId());
		soapModel.setFirstName(model.getFirstName());
		soapModel.setLastName(model.getLastName());
		soapModel.setEmail(model.getEmail());
		soapModel.setPassword(model.getPassword());
		soapModel.setMobileNo(model.getMobileNo());
		soapModel.setDateOfBirth(model.getDateOfBirth());
		soapModel.setGender(model.getGender());
		soapModel.setHobby(model.getHobby());
		soapModel.setAddress(model.getAddress());
		soapModel.setStream(model.getStream());
		soapModel.setCity(model.getCity());
		soapModel.setLanguage(model.getLanguage());
		soapModel.setImage(model.getImage());

		return soapModel;
	}

	public static crudSoap[] toSoapModels(crud[] models) {
		crudSoap[] soapModels = new crudSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static crudSoap[][] toSoapModels(crud[][] models) {
		crudSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new crudSoap[models.length][models[0].length];
		}
		else {
			soapModels = new crudSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static crudSoap[] toSoapModels(List<crud> models) {
		List<crudSoap> soapModels = new ArrayList<crudSoap>(models.size());

		for (crud model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new crudSoap[soapModels.size()]);
	}

	public crudSoap() {
	}

	public int getPrimaryKey() {
		return _id;
	}

	public void setPrimaryKey(int pk) {
		setId(pk);
	}

	public int getId() {
		return _id;
	}

	public void setId(int id) {
		_id = id;
	}

	public String getFirstName() {
		return _firstName;
	}

	public void setFirstName(String firstName) {
		_firstName = firstName;
	}

	public String getLastName() {
		return _lastName;
	}

	public void setLastName(String lastName) {
		_lastName = lastName;
	}

	public String getEmail() {
		return _email;
	}

	public void setEmail(String email) {
		_email = email;
	}

	public String getPassword() {
		return _password;
	}

	public void setPassword(String password) {
		_password = password;
	}

	public long getMobileNo() {
		return _mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		_mobileNo = mobileNo;
	}

	public Date getDateOfBirth() {
		return _dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		_dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return _gender;
	}

	public void setGender(String gender) {
		_gender = gender;
	}

	public String getHobby() {
		return _hobby;
	}

	public void setHobby(String hobby) {
		_hobby = hobby;
	}

	public String getAddress() {
		return _address;
	}

	public void setAddress(String address) {
		_address = address;
	}

	public String getStream() {
		return _stream;
	}

	public void setStream(String stream) {
		_stream = stream;
	}

	public String getCity() {
		return _city;
	}

	public void setCity(String city) {
		_city = city;
	}

	public String getLanguage() {
		return _language;
	}

	public void setLanguage(String language) {
		_language = language;
	}

	public String getImage() {
		return _image;
	}

	public void setImage(String image) {
		_image = image;
	}

	private int _id;
	private String _firstName;
	private String _lastName;
	private String _email;
	private String _password;
	private long _mobileNo;
	private Date _dateOfBirth;
	private String _gender;
	private String _hobby;
	private String _address;
	private String _stream;
	private String _city;
	private String _language;
	private String _image;

}