/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package t.service.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link crud}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see crud
 * @generated
 */
public class crudWrapper
	extends BaseModelWrapper<crud> implements crud, ModelWrapper<crud> {

	public crudWrapper(crud crud) {
		super(crud);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("id", getId());
		attributes.put("firstName", getFirstName());
		attributes.put("lastName", getLastName());
		attributes.put("email", getEmail());
		attributes.put("password", getPassword());
		attributes.put("mobileNo", getMobileNo());
		attributes.put("dateOfBirth", getDateOfBirth());
		attributes.put("gender", getGender());
		attributes.put("hobby", getHobby());
		attributes.put("address", getAddress());
		attributes.put("stream", getStream());
		attributes.put("city", getCity());
		attributes.put("language", getLanguage());
		attributes.put("image", getImage());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Integer id = (Integer)attributes.get("id");

		if (id != null) {
			setId(id);
		}

		String firstName = (String)attributes.get("firstName");

		if (firstName != null) {
			setFirstName(firstName);
		}

		String lastName = (String)attributes.get("lastName");

		if (lastName != null) {
			setLastName(lastName);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String password = (String)attributes.get("password");

		if (password != null) {
			setPassword(password);
		}

		Long mobileNo = (Long)attributes.get("mobileNo");

		if (mobileNo != null) {
			setMobileNo(mobileNo);
		}

		Date dateOfBirth = (Date)attributes.get("dateOfBirth");

		if (dateOfBirth != null) {
			setDateOfBirth(dateOfBirth);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String hobby = (String)attributes.get("hobby");

		if (hobby != null) {
			setHobby(hobby);
		}

		String address = (String)attributes.get("address");

		if (address != null) {
			setAddress(address);
		}

		String stream = (String)attributes.get("stream");

		if (stream != null) {
			setStream(stream);
		}

		String city = (String)attributes.get("city");

		if (city != null) {
			setCity(city);
		}

		String language = (String)attributes.get("language");

		if (language != null) {
			setLanguage(language);
		}

		String image = (String)attributes.get("image");

		if (image != null) {
			setImage(image);
		}
	}

	/**
	 * Returns the address of this crud.
	 *
	 * @return the address of this crud
	 */
	@Override
	public String getAddress() {
		return model.getAddress();
	}

	/**
	 * Returns the city of this crud.
	 *
	 * @return the city of this crud
	 */
	@Override
	public String getCity() {
		return model.getCity();
	}

	/**
	 * Returns the date of birth of this crud.
	 *
	 * @return the date of birth of this crud
	 */
	@Override
	public Date getDateOfBirth() {
		return model.getDateOfBirth();
	}

	/**
	 * Returns the email of this crud.
	 *
	 * @return the email of this crud
	 */
	@Override
	public String getEmail() {
		return model.getEmail();
	}

	/**
	 * Returns the first name of this crud.
	 *
	 * @return the first name of this crud
	 */
	@Override
	public String getFirstName() {
		return model.getFirstName();
	}

	/**
	 * Returns the gender of this crud.
	 *
	 * @return the gender of this crud
	 */
	@Override
	public String getGender() {
		return model.getGender();
	}

	/**
	 * Returns the hobby of this crud.
	 *
	 * @return the hobby of this crud
	 */
	@Override
	public String getHobby() {
		return model.getHobby();
	}

	/**
	 * Returns the ID of this crud.
	 *
	 * @return the ID of this crud
	 */
	@Override
	public int getId() {
		return model.getId();
	}

	/**
	 * Returns the image of this crud.
	 *
	 * @return the image of this crud
	 */
	@Override
	public String getImage() {
		return model.getImage();
	}

	/**
	 * Returns the language of this crud.
	 *
	 * @return the language of this crud
	 */
	@Override
	public String getLanguage() {
		return model.getLanguage();
	}

	/**
	 * Returns the last name of this crud.
	 *
	 * @return the last name of this crud
	 */
	@Override
	public String getLastName() {
		return model.getLastName();
	}

	/**
	 * Returns the mobile no of this crud.
	 *
	 * @return the mobile no of this crud
	 */
	@Override
	public long getMobileNo() {
		return model.getMobileNo();
	}

	/**
	 * Returns the password of this crud.
	 *
	 * @return the password of this crud
	 */
	@Override
	public String getPassword() {
		return model.getPassword();
	}

	/**
	 * Returns the primary key of this crud.
	 *
	 * @return the primary key of this crud
	 */
	@Override
	public int getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the stream of this crud.
	 *
	 * @return the stream of this crud
	 */
	@Override
	public String getStream() {
		return model.getStream();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the address of this crud.
	 *
	 * @param address the address of this crud
	 */
	@Override
	public void setAddress(String address) {
		model.setAddress(address);
	}

	/**
	 * Sets the city of this crud.
	 *
	 * @param city the city of this crud
	 */
	@Override
	public void setCity(String city) {
		model.setCity(city);
	}

	/**
	 * Sets the date of birth of this crud.
	 *
	 * @param dateOfBirth the date of birth of this crud
	 */
	@Override
	public void setDateOfBirth(Date dateOfBirth) {
		model.setDateOfBirth(dateOfBirth);
	}

	/**
	 * Sets the email of this crud.
	 *
	 * @param email the email of this crud
	 */
	@Override
	public void setEmail(String email) {
		model.setEmail(email);
	}

	/**
	 * Sets the first name of this crud.
	 *
	 * @param firstName the first name of this crud
	 */
	@Override
	public void setFirstName(String firstName) {
		model.setFirstName(firstName);
	}

	/**
	 * Sets the gender of this crud.
	 *
	 * @param gender the gender of this crud
	 */
	@Override
	public void setGender(String gender) {
		model.setGender(gender);
	}

	/**
	 * Sets the hobby of this crud.
	 *
	 * @param hobby the hobby of this crud
	 */
	@Override
	public void setHobby(String hobby) {
		model.setHobby(hobby);
	}

	/**
	 * Sets the ID of this crud.
	 *
	 * @param id the ID of this crud
	 */
	@Override
	public void setId(int id) {
		model.setId(id);
	}

	/**
	 * Sets the image of this crud.
	 *
	 * @param image the image of this crud
	 */
	@Override
	public void setImage(String image) {
		model.setImage(image);
	}

	/**
	 * Sets the language of this crud.
	 *
	 * @param language the language of this crud
	 */
	@Override
	public void setLanguage(String language) {
		model.setLanguage(language);
	}

	/**
	 * Sets the last name of this crud.
	 *
	 * @param lastName the last name of this crud
	 */
	@Override
	public void setLastName(String lastName) {
		model.setLastName(lastName);
	}

	/**
	 * Sets the mobile no of this crud.
	 *
	 * @param mobileNo the mobile no of this crud
	 */
	@Override
	public void setMobileNo(long mobileNo) {
		model.setMobileNo(mobileNo);
	}

	/**
	 * Sets the password of this crud.
	 *
	 * @param password the password of this crud
	 */
	@Override
	public void setPassword(String password) {
		model.setPassword(password);
	}

	/**
	 * Sets the primary key of this crud.
	 *
	 * @param primaryKey the primary key of this crud
	 */
	@Override
	public void setPrimaryKey(int primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the stream of this crud.
	 *
	 * @param stream the stream of this crud
	 */
	@Override
	public void setStream(String stream) {
		model.setStream(stream);
	}

	@Override
	protected crudWrapper wrap(crud crud) {
		return new crudWrapper(crud);
	}

}