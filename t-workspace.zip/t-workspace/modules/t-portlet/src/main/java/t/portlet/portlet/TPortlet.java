package t.portlet.portlet;

import t.portlet.constants.TPortletKeys;
import t.service.model.crud;
import t.service.service.crudLocalService;
import t.service.service.crudLocalServiceUtil;
import t.service.service.crudService;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

/**
 * @author Marshal Dekivadiya
 */
@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css", "com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=T", "javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp", "javax.portlet.name=" + TPortletKeys.T,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" }, service = Portlet.class)
public class TPortlet extends MVCPortlet {

	private CounterLocalServiceUtil counterLocalServiceUtil;

	@Reference
	private crudService service;

	// -----------------------Data Register Method----------------------//

	@ProcessAction(name = "/registration")
	public void registration(ActionRequest actionRequest, ActionResponse actionResponse) {

		int count = (int) counterLocalServiceUtil.increment(TPortlet.class.getName());

		String firstName = ParamUtil.getString(actionRequest, "firstName");
		String lastName = ParamUtil.getString(actionRequest, "lastName");
		String email = ParamUtil.getString(actionRequest, "email");
		String password = ParamUtil.getString(actionRequest, "password");
		java.util.Date dateOfBirth = ParamUtil.getDate(actionRequest, "dateOfBirth",
				new SimpleDateFormat("yyyy-MM-dd"));
		long mobileNo = ParamUtil.getLong(actionRequest, "mobileNo");

		String language[] = ParamUtil.getStringValues(actionRequest, "language");
		String language_list = "";
		int language_length = language.length;
		for (int i = 0; i < language_length; i++) {
			if (i == language_length - 1) {
				language_list += language[i];
			} else {
				language_list += language[i] + ",";
			}
		}

		String gender = ParamUtil.getString(actionRequest, "gender");
		String stream = ParamUtil.getString(actionRequest, "stream");
		String city = ParamUtil.getString(actionRequest, "city");
		String image = ParamUtil.getString(actionRequest, "image");

		String hobby[] = ParamUtil.getStringValues(actionRequest, "hobby");
		String hobby_list = "";

		int hobby_len = hobby.length;

		for (int i = 0; i < hobby_len; i++) {
			if (i == hobby_len - 1) {
				hobby_list += hobby[i];
			} else {
				hobby_list += hobby[i] + ",";
			}
		}

		
		String address = ParamUtil.getString(actionRequest, "address");
		
		List<crud> list  = 	service.findByEmail(email);
		if(list.isEmpty()) {
			
		crud model = crudLocalServiceUtil.createcrud(count);
		model.setFirstName(firstName);
		model.setLastName(lastName);
		model.setEmail(email);
		model.setPassword(password);
		model.setImage(image);
		model.setCity(city);
		model.setDateOfBirth(dateOfBirth);
		model.setStream(stream);
		model.setAddress(address);
		model.setLanguage(language_list);
		model.setMobileNo(mobileNo);
		model.setHobby(hobby_list);
		model.setGender(gender);

		System.out.println(model);

		crudLocalServiceUtil.addcrud(model);
		actionRequest.setAttribute("registrationMsg","Registraion Succesfully.." );
		 
		}
		else {
			 actionRequest.setAttribute("msg","Email Id Already Registerd" );
			 actionResponse.getRenderParameters().setValues("jspPage", "/registration.jsp");

		}
		
		
	}
	
	//-----------------------List all the Data ------------------------------//
	@Override
	public void doView(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
			renderRequest.setAttribute("data", crudLocalServiceUtil.getcruds(0, 10));
		super.doView(renderRequest, renderResponse);
	}

	//---------------------------------Update Data---------------------------------//
	@ProcessAction(name="edit")
	public void update(ActionRequest actionRequest, ActionResponse actionResponse) throws PortalException {
		
		int id = ParamUtil.getInteger(actionRequest, "id");
		String firstName = ParamUtil.getString(actionRequest, "firstName");
		String lastName = ParamUtil.getString(actionRequest, "lastName");
		java.util.Date dateOfBirth = ParamUtil.getDate(actionRequest, "dateOfBirth",
				new SimpleDateFormat("yyyy-MM-dd"));
		String language[] = ParamUtil.getStringValues(actionRequest, "language");
		String language_list = "";
		int language_length = language.length;
		for (int i = 0; i < language_length; i++) {
			if (i == language_length - 1) {
				language_list += language[i];
			} else {
				language_list += language[i] + ",";
			}
		}

		String gender = ParamUtil.getString(actionRequest, "gender");
		String stream = ParamUtil.getString(actionRequest, "stream");
		String city = ParamUtil.getString(actionRequest, "city");
		String hobby[] = ParamUtil.getStringValues(actionRequest, "hobby");
		String hobby_list = "";

		int hobby_len = hobby.length;

		for (int i = 0; i < hobby_len; i++) {
			if (i == hobby_len - 1) {
				hobby_list += hobby[i];
			} else {
				hobby_list += hobby[i] + ",";
			}
		}

		String address = ParamUtil.getString(actionRequest, "address");
		
		crud model = crudLocalServiceUtil.getcrud(id);
		model.setFirstName(firstName);
		model.setLastName(lastName);
		model.setCity(city);
		model.setDateOfBirth(dateOfBirth);
		model.setStream(stream);
		model.setAddress(address);
		model.setLanguage(language_list);
		model.setHobby(hobby_list);
		model.setGender(gender);

		crudLocalServiceUtil.updatecrud(model);	
		actionRequest.setAttribute("updateMsg","Update Succesfully.." );
		
	}
	
	//------------------------ServeResource Method for Delete Data------------------------------//
	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		try {
			int id = ParamUtil.getInteger(resourceRequest, "id");
			
			crudLocalServiceUtil.deletecrud(id);
			resourceRequest.setAttribute("deleteMsg","Delete Succesfully.." );
			
		} catch (PortalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		super.serveResource(resourceRequest, resourceResponse);
	}
}	