package t.portlet.portlet;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCActionCommand;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCRenderCommand;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.osgi.service.component.annotations.Component;

import t.portlet.constants.TPortletKeys;
import t.service.service.crudLocalServiceUtil;

@Component(immediate = true, property = { "javax.portlet.name=" + TPortletKeys.T,
		"mvc.command.name=edit" }, service = MVCRenderCommand.class)
public class edit implements MVCRenderCommand{

	
	@Override
	public String render(RenderRequest renderRequest, RenderResponse renderResponse) throws PortletException {
		int id = ParamUtil.getInteger(renderRequest, "id");
		System.out.println(id);
		
		if(id>0) {
			try {
				renderRequest.setAttribute("data", crudLocalServiceUtil.getcrud(id));
			} catch (PortalException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("render");
		return "/edit.jsp";

	}
	

}
