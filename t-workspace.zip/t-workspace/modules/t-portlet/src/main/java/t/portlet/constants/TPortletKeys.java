package t.portlet.constants;

/**
 * @author Marshal Dekivadiya
 */
public class TPortletKeys {

	public static final String T =
		"t_portlet_TPortlet";

}